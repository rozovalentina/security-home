package com.example.proyecto;

import dagger.hilt.android.HiltAndroidApp;

@HiltAndroidApp
public class App extends android.app.Application {
}
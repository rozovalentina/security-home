Descripción

Security Home es una aplicación de seguridad en el hogar que utiliza sensores para detectar movimiento, temperatura y otras condiciones ambientales y brinda seguimiento en tiempo real. Además, incluye una función de chat para comunicarse con familiares y amigos y una función de mapa para ver la ubicación de la casa o compartirla con ellos.

Está diseñado para ofrecr una solución de seguimiento en tiempo real y alertas de emergencia para la seguridad del hogar, incluye una función de chat y mapa para mejorar la comunicación y coordinación en situaciones de emergencia.

Características

Control de cámaras y sensores.

Chat en vivo con el grupo familiar

Ubicación en vivo
